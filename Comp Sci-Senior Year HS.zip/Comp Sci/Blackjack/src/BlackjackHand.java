//Ben Germroth
public class BlackjackHand extends Hand {
	private int handValue;
	private boolean soft;
	BlackjackHand(){
		handValue=0;soft=false;
	}
	private void computeValue(){
		handValue=0;
		aces=false;
		soft=false;
		int get = 0;
		for(int i=0;i<numberOfCards();i++){
			get = nthCard(i).getValue();
			if(get==PlayingCard.KING||get==PlayingCard.JACK||get==PlayingCard.QUEEN){
				handValue+=10;
			} else {
				handValue+=get;
			}
			if(get==PlayingCard.ACE)
				aces=true;
		}
		if(aces&&handValue<12){
			handValue+=10; soft=true;
		}
	}
	public void addCard(PlayingCard a){
		super.addCard(a);
		computeValue();
	}
	public int handValue(){
		return handValue;
	}
	public boolean soft(){
		return soft;
	}
}
