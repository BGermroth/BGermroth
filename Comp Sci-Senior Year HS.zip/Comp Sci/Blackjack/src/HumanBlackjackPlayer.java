//Ben Germroth
import java.util.Scanner;
public class HumanBlackjackPlayer extends BlackjackPlayer{
	public boolean hit(BlackjackHand dealerHand, BlackjackHand playerHand) {
		System.out.println("Player's Hand:");playerHand.print();
		System.out.println("Dealer's Hand:");dealerHand.print();
		Scanner userInput = new Scanner(System.in);
		while(true){
		System.out.print("Do you want to hit(y/n): ");
		String input = userInput.next();
		if(input.equalsIgnoreCase("y"))
			return true;
		else if(input.equalsIgnoreCase("n"))
			return false;
		else
			System.out.println("Not a valid answer");
		}
	}
	public void dealerHit(BlackjackHand dealerHand) {
		System.out.println("The dealer hit:");dealerHand.print();
	}
	public void playerBusts(BlackjackHand playerHand) {
		System.out.println("You busted"+"\n"+"Your hand:");playerHand.print();
	}
	public void playerTies(BlackjackHand playerHand, BlackjackHand dealerHand) {
		System.out.println("You tied the dealer"+"\n"+"Your hand:");playerHand.print();
		System.out.println("Dealer's hand:");dealerHand.print();
	}
	public void playerWins(BlackjackHand playerHand, BlackjackHand dealerHand) {
		System.out.println("You win"+"\n"+"Your hand:");playerHand.print();
		System.out.println("Dealer's hand:");dealerHand.print();
	}
	public void dealerBusts(BlackjackHand dealerHand) {
		System.out.println("The dealer busted");dealerHand.print();
	}
	public void dealerWins(BlackjackHand dealerHand, BlackjackHand playerHand) {
		System.out.println("The dealer wins");dealerHand.print();
	}
}
