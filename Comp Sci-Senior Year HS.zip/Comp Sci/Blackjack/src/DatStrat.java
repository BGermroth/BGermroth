//Ben Germroth
import java.lang.Math;
public class DatStrat extends BlackjackStrategy{
	public boolean hit(int handValue, int dealerHandValue, boolean soft) {
		if(((dealerHandValue==11&&handValue<21)&&handValue<17)||soft){
			return true;
		}
		if(handValue==15){
			int why = (int)Math.random()*100;
			if(why<50)
				return true;
			return false;
		}
		return false;
	}
}