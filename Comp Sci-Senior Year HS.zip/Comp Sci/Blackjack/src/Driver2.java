//Ben Germroth
public class Driver2 {

	public static void main(String[] args) {
		BlackjackStrategy tryme = new DatStrat();
		BlackjackPlayer player = new ComputerBlackjackPlayer(tryme);
		BlackjackDealer deals = new BlackjackDealer();
		double gimme = deals.playBlackjack(player,90000);//Math.random() if(handvalue is less than 15 then generate a random number)
		System.out.println(gimme);
	}
}
