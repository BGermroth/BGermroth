//Ben Germroth
public class BlackjackDealer {
	public double playBlackjack(BlackjackPlayer player, int numGames){
		boolean why=true;
		double score=0;
		final int games=numGames;
		do {
			BlackjackHand dealerHand = new BlackjackHand();
			BlackjackHand playerHand = new BlackjackHand();
			dealerHand.addCard(new PlayingCard());
			playerHand.addCard(new PlayingCard());
			playerHand.addCard(new PlayingCard());
			boolean again=true;
			do {
				if(player.hit(dealerHand,playerHand)){
					playerHand.addCard(new PlayingCard());
					if(playerHand.handValue()>21){
						player.playerBusts(playerHand);
						why=false;again=false;
					}
				} else
					again=false;
			} while(again);
			again=true;
			if(why){
				do {
					if(dealerHand.handValue()<17){
						dealerHand.addCard(new PlayingCard());
						player.dealerHit(dealerHand);
					} else if(dealerHand.handValue()>21){
						player.dealerBusts(dealerHand);
						score+=1;
						again=false;
					} else if(dealerHand.handValue()==playerHand.handValue()){
						player.playerTies(playerHand,dealerHand);
						score+=0.5;
						again=false;
					} else if(dealerHand.handValue()>playerHand.handValue()&&dealerHand.handValue()<22){
						player.dealerWins(dealerHand,playerHand);
						again=false;
					} else if(playerHand.handValue()>dealerHand.handValue()&&playerHand.handValue()<22){
						player.playerWins(playerHand,dealerHand);
						score+=1;
						again=false;
					}
				} while(again);
			}
			why=true;
			numGames--;
		} while(numGames>0);
		return score/games;
	}
}