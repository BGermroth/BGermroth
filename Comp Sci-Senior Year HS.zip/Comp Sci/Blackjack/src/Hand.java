//Ben Germroth
import java.util.ArrayList;
public class Hand {
	boolean aces;
	protected ArrayList<PlayingCard> a1;
	Hand(){
		a1 = new ArrayList<PlayingCard>();
	}
	public int numberOfCards(){
		return a1.size();
	}
	public PlayingCard nthCard(int n){
		return a1.get(n);
	}
	public void print(){
		for(Object a : a1){
			System.out.println(a);
		}
	}
	public void addCard(PlayingCard a){
		a1.add(a);
	}
}
