//Ben Germroth
public class Driver {
	public static void BlackJack1(){
		PlayingCard letsplay = new PlayingCard();
		PlayingCard again = new PlayingCard();
		PlayingCard keepgoing = new PlayingCard();
		PlayingCard done = new PlayingCard();

		System.out.println("Random:");
		System.out.println(letsplay.toString());
		System.out.println(again.toString());

		System.out.println("Not random:");
		PlayingCard.setRandom(false);
		PlayingCard more = new PlayingCard();
		System.out.println(more.toString());
		PlayingCard morestill = new PlayingCard();
		System.out.println(morestill.toString());

		System.out.println("Random again:");
		PlayingCard.setRandom(true);
		System.out.println(keepgoing.toString());
		System.out.println(done.toString());

		System.out.println("13 Set Cards:");
		PlayingCard last = new PlayingCard(PlayingCard.HEARTS,3);
		System.out.println(last.toString());
		last = new PlayingCard(PlayingCard.SPADES,2);
		System.out.println(last.toString());
		last = new PlayingCard(PlayingCard.HEARTS,PlayingCard.KING);
		System.out.println(last.toString());
		last = new PlayingCard(PlayingCard.DIAMONDS,2);
		System.out.println(last.toString());
		last = new PlayingCard(PlayingCard.CLUBS,PlayingCard.QUEEN);
		System.out.println(last.toString());
		last = new PlayingCard(PlayingCard.HEARTS,PlayingCard.JACK);
		System.out.println(last.toString());
		last = new PlayingCard(PlayingCard.CLUBS,7);
		System.out.println(last.toString());
		last = new PlayingCard(PlayingCard.HEARTS,PlayingCard.ACE);
		System.out.println(last.toString());
		last = new PlayingCard(PlayingCard.SPADES,5);
		System.out.println(last.toString());
		last = new PlayingCard(PlayingCard.SPADES,PlayingCard.KING);
		System.out.println(last.toString());
		last = new PlayingCard(PlayingCard.CLUBS,2);
		System.out.println(last.toString());
		last = new PlayingCard(PlayingCard.DIAMONDS,PlayingCard.ACE);
		System.out.println(last.toString());
		last = new PlayingCard(PlayingCard.HEARTS,9);
		System.out.println(last.toString());
	}
	public static void BlackJack2Test(){
		PlayingCard letsplay = new PlayingCard(PlayingCard.SPADES,4);
		PlayingCard again = new PlayingCard(PlayingCard.HEARTS,9);
		PlayingCard keepgoing = new PlayingCard(PlayingCard.CLUBS,PlayingCard.KING);
		PlayingCard done = new PlayingCard(PlayingCard.DIAMONDS,3);

		Hand why = new Hand();

		why.addCard(letsplay);
		why.addCard(again);
		why.addCard(keepgoing);
		why.addCard(done);
		why.print();

		System.out.println(why.numberOfCards());
		System.out.println("1st card: "+why.nthCard(1));
	}
	public static void BlackJack2(){
		Hand play = new Hand();
		Hand temp = new Hand();
		Hand again = new Hand();
		Hand still = new Hand();

		temp.addCard(new PlayingCard());
		again.addCard(new PlayingCard());
		again.addCard(new PlayingCard());
		still.addCard(new PlayingCard());
		still.addCard(new PlayingCard());
		still.addCard(new PlayingCard());

		System.out.println("play num: "+play.numberOfCards());
		System.out.println("temp num: "+temp.numberOfCards());
		System.out.println("again num: "+again.numberOfCards());
		System.out.println("temp at 0: "+temp.nthCard(0));
		System.out.println("again at 0: "+again.nthCard(0));
		System.out.println("again at 1: "+again.nthCard(1));
		System.out.println("still at middle: "+still.nthCard(still.numberOfCards()/2));

		play.print();
		temp.print();
		again.print();
		still.print();
	}
	public static void BlackHand(){
		BlackjackHand faceValue = new BlackjackHand();
		BlackjackHand multiAce = new BlackjackHand();
		BlackjackHand aceAbove = new BlackjackHand();
		BlackjackHand aces = new BlackjackHand();
		BlackjackHand black = new BlackjackHand();
		BlackjackHand firstHard = new BlackjackHand();
		BlackjackHand firstSoft = new BlackjackHand();
		BlackjackHand secondHard = new BlackjackHand();
		BlackjackHand secondSoft = new BlackjackHand();
		BlackjackHand small = new BlackjackHand();
		BlackjackHand last = new BlackjackHand();

		faceValue.addCard(new PlayingCard(PlayingCard.SPADES,PlayingCard.QUEEN));
		faceValue.addCard(new PlayingCard(PlayingCard.DIAMONDS,PlayingCard.JACK));
		faceValue.addCard(new PlayingCard(PlayingCard.CLUBS,PlayingCard.KING));
		multiAce.addCard(new PlayingCard(PlayingCard.DIAMONDS,PlayingCard.ACE));
		multiAce.addCard(new PlayingCard(PlayingCard.CLUBS,PlayingCard.ACE));
		multiAce.addCard(new PlayingCard(PlayingCard.DIAMONDS,PlayingCard.ACE));
		aceAbove.addCard(new PlayingCard(PlayingCard.SPADES,PlayingCard.QUEEN));
		aceAbove.addCard(new PlayingCard(PlayingCard.CLUBS,5));
		aceAbove.addCard(new PlayingCard(PlayingCard.CLUBS,PlayingCard.ACE));
		aces.addCard(new PlayingCard(PlayingCard.DIAMONDS,PlayingCard.ACE));
		aces.addCard(new PlayingCard(PlayingCard.SPADES,PlayingCard.ACE));
		aces.addCard(new PlayingCard(PlayingCard.HEARTS,PlayingCard.ACE));
		aces.addCard(new PlayingCard(PlayingCard.SPADES,PlayingCard.ACE));
		aces.addCard(new PlayingCard(PlayingCard.SPADES,PlayingCard.ACE));
		black.addCard(new PlayingCard(PlayingCard.DIAMONDS,PlayingCard.ACE));
		black.addCard(new PlayingCard(PlayingCard.SPADES,PlayingCard.QUEEN));
		firstHard.addCard(new PlayingCard(PlayingCard.CLUBS,PlayingCard.ACE));
		firstHard.addCard(new PlayingCard(PlayingCard.SPADES,9));
		firstHard.addCard(new PlayingCard(PlayingCard.CLUBS,8));
		firstHard.addCard(new PlayingCard(PlayingCard.CLUBS,4));
		firstSoft.addCard(new PlayingCard(PlayingCard.DIAMONDS,PlayingCard.ACE));
		firstSoft.addCard(new PlayingCard(PlayingCard.DIAMONDS,9));
		secondHard.addCard(new PlayingCard(PlayingCard.SPADES,9));
		secondHard.addCard(new PlayingCard(PlayingCard.HEARTS,10));
		secondHard.addCard(new PlayingCard(PlayingCard.CLUBS,PlayingCard.ACE));
		secondSoft.addCard(new PlayingCard(PlayingCard.DIAMONDS,9));
		secondSoft.addCard(new PlayingCard(PlayingCard.SPADES,PlayingCard.ACE));
		small.addCard(new PlayingCard(PlayingCard.HEARTS,3));
		small.addCard(new PlayingCard(PlayingCard.HEARTS,6));
		last.addCard(new PlayingCard(PlayingCard.SPADES,PlayingCard.ACE));
		last.addCard(new PlayingCard(PlayingCard.DIAMONDS,PlayingCard.KING));
		last.addCard(new PlayingCard(PlayingCard.CLUBS,2));

		System.out.println("faceValue:");faceValue.print();
		System.out.println("Soft: "+faceValue.soft());
		System.out.println("Hand Value: "+faceValue.handValue());
		System.out.println("multiAce:");multiAce.print();
		System.out.println("Soft: "+multiAce.soft());
		System.out.println("Hand Value: "+multiAce.handValue());
		System.out.println("aceAbove:");aceAbove.print();
		System.out.println("Soft: "+aceAbove.soft());
		System.out.println("Hand Value: "+aceAbove.handValue());
		System.out.println("aces:");aces.print();
		System.out.println("Soft: "+aces.soft());
		System.out.println("Hand Value: "+aces.handValue());
		System.out.println("black:");black.print();
		System.out.println("Soft: "+black.soft());
		System.out.println("Hand Value: "+black.handValue());
		System.out.println("firstHard:");firstHard.print();
		System.out.println("Soft: "+firstHard.soft());
		System.out.println("Hand Value: "+firstHard.handValue());
		System.out.println("firstSoft:");firstSoft.print();
		System.out.println("Soft: "+firstSoft.soft());
		System.out.println("Hand Value: "+firstSoft.handValue());
		System.out.println("secondHard:");secondHard.print();
		System.out.println("Soft: "+secondHard.soft());
		System.out.println("Hand Value: "+secondHard.handValue());
		System.out.println("secondSoft:");secondSoft.print();
		System.out.println("Soft: "+secondSoft.soft());
		System.out.println("Hand Value: "+secondSoft.handValue());
		System.out.println("small:");small.print();
		System.out.println("Soft: "+small.soft());
		System.out.println("Hand Value: "+small.handValue());
		System.out.println("last:");last.print();
		System.out.println("Soft: "+last.soft());
		System.out.println("Hand Value: "+last.handValue());
	}
	public static void HumanBlackjack(){
		BlackjackHand playerHand = new BlackjackHand();
		BlackjackHand dealerHand = new BlackjackHand();
		HumanBlackjackPlayer letsgo = new HumanBlackjackPlayer();

		playerHand.addCard(new PlayingCard(PlayingCard.SPADES, PlayingCard.ACE));
		dealerHand.addCard(new PlayingCard(PlayingCard.HEARTS, 3));

		System.out.println("Hit time:");
		letsgo.hit(dealerHand,playerHand);
		letsgo.dealerHit(dealerHand);
		letsgo.playerBusts(playerHand);
		letsgo.playerTies(playerHand,dealerHand);
		letsgo.playerWins(playerHand,dealerHand);
		letsgo.dealerBusts(dealerHand);
		letsgo.dealerWins(dealerHand,playerHand);
	}
	public static void DealingTime(){
		BlackjackPlayer player = new HumanBlackjackPlayer();
		BlackjackDealer deals = new BlackjackDealer();
		System.out.println(deals.playBlackjack(player,6));
	}
	public static void compute(){
		BlackjackStrategy tryme = new MySimpleStrategy();
		BlackjackPlayer player = new ComputerBlackjackPlayer(tryme);
		BlackjackDealer deals = new BlackjackDealer();
		double gimme = deals.playBlackjack(player,1000);//Math.random() if(handvalue is less than 15 then generate a random number)
		System.out.println(gimme);
	}
	public static void lastTime(){
		MySimpleStrategy tryme = new MySimpleStrategy();
		System.out.println(tryme.hit(15,11,true));
		System.out.println(tryme.hit(15,11,false));
		System.out.println(tryme.hit(11,10,false));
		System.out.println(tryme.hit(17,7,false));
		System.out.println(tryme.hit(16,6,false));
		System.out.println(tryme.hit(17,2,true));
	}
	public static void main(String[] args) {
		//BlackJack1();
		//BlackJack2();
		//BlackHand();
		//HumanBlackjack();
		//DealingTime();
		compute();
		//lastTime();
	}
}
//12 4 10 1 7 3 n 6 2 11 1 dealer busts
//10 3 5 1 4 2 y 10 2 y 5 4 player busts
// Tie