//Ben Germroth
public abstract class BlackjackStrategy {
	public abstract boolean hit(int handValue,int dealerHandValue,boolean soft);
}
