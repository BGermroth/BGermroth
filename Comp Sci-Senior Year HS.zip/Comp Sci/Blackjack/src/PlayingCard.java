//Ben Germroth
import java.util.Scanner;
public class PlayingCard {
	private int suit, value;
	public static final int ACE = 1;
	public static final int KING = 13;
	public static final int QUEEN = 12;
	public static final int JACK = 11;
	public static final int HEARTS = 1;
	public static final int SPADES = 2;
	public static final int CLUBS = 3;
	public static final int DIAMONDS = 4;
	private static boolean random = true;
	PlayingCard(int a, int b){
		suit = a;
		value = b;
	}
	PlayingCard(){
		if(random){
			suit = (int)(Math.random()*4)+1;
			value = (int)(Math.random()*13)+1;
		} else {
			Scanner userInput = new Scanner(System.in);
			System.out.print("Face value: ");
			String Value = userInput.next();
			value = Integer.parseInt(Value);
			System.out.print("Suit: ");
			String Suit = userInput.next();
			suit = Integer.parseInt(Suit);
		}
	}
	public int getSuit(){
		return suit;
	}
	public int getValue(){
		return value;
	}
	public String toString(){
		String last = "";
		switch(value){
		case 1: last="A of "; break;
		case 2: last="Two of "; break;
		case 3: last="Three of "; break;
		case 4: last="Four of "; break;
		case 5: last="Five of "; break;
		case 6: last="Six of "; break;
		case 7: last="Seven of "; break;
		case 8: last="Eight of "; break;
		case 9: last="Nine of "; break;
		case 10: last="Ten of "; break;
		case 11: last="Jack of "; break;
		case 12: last="Queen of "; break;
		case 13: last="King of "; break;
		}
		switch(suit){
		case 1: last+="Hearts"; break;
		case 2: last+="Spades"; break;
		case 3: last+="Clubs"; break;
		case 4: last+="Diamonds"; break;
		}
		return last;
	}
	public static void setRandom(boolean yes){
		random = yes;
	}
}
